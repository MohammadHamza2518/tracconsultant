var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__12x9e8p._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_1ox7zi0.js")
R.m(74378)
module.exports=R.m(74378).exports

module.exports=[24500,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_tax-calculator_page_actions_1t3gf7d.js.map
var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tools/purchase/route.js")
R.c("server/chunks/[root-of-the-server]__11xq995._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_tools_purchase_route_actions_1o-3p7j.js")
R.m(74330)
module.exports=R.m(74330).exports

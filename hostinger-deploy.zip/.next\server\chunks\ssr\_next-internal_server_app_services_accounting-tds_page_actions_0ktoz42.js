module.exports=[2133,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_accounting-tds_page_actions_0ktoz42.js.map
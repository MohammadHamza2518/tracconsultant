module.exports=[49697,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_pdf-redactor_page_actions_0ohtni1.js.map
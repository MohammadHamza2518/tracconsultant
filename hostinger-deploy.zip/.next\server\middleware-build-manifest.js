globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/RL1NcMMj09uiI2voFt2eD/_buildManifest.js",
    "static/RL1NcMMj09uiI2voFt2eD/_ssgManifest.js",
    "static/RL1NcMMj09uiI2voFt2eD/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/3b-_250g_uom6.js",
    "static/chunks/1x1zbuyxonexj.js",
    "static/chunks/turbopack-436ncxzvrtt03.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};

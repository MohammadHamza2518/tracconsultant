module.exports=[6046,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_templates_route_actions_1kz0oyw.js.map
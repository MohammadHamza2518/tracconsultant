module.exports=[80536,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_tb-to-balancesheet_page_actions_1u33djz.js.map
module.exports=[430,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_hra-calculator_page_actions_0ec4trp.js.map
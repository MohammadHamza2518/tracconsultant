module.exports=[51662,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_json-to-computation_page_actions_1ofl-g8.js.map
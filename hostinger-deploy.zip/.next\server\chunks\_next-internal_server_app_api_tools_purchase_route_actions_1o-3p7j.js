module.exports=[8896,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tools_purchase_route_actions_1o-3p7j.js.map
module.exports=[74740,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tools_advance-tax-calculator_page_actions_0p-ic48.js.map
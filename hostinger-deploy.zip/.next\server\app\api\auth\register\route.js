var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__1kiqioe._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_0g4vfdr.js")
R.m(89124)
module.exports=R.m(89124).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/filings/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0d236r5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_filings_[id]_route_actions_0b-hnf_.js")
R.m(45358)
module.exports=R.m(45358).exports

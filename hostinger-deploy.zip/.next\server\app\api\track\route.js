var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/track/route.js")
R.c("server/chunks/[root-of-the-server]__19jdmtb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_track_route_actions_0eauih4.js")
R.m(3134)
module.exports=R.m(3134).exports

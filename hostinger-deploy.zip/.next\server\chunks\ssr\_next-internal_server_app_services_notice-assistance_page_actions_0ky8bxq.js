module.exports=[46175,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_services_notice-assistance_page_actions_0ky8bxq.js.map
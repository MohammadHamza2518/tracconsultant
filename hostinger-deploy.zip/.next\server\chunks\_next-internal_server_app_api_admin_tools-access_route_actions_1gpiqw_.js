module.exports=[96744,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_tools-access_route_actions_1gpiqw_.js.map
var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/send/route.js")
R.c("server/chunks/[root-of-the-server]__0buh6a5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_send_route_actions_1vgn_g2.js")
R.m(51820)
module.exports=R.m(51820).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/templates/route.js")
R.c("server/chunks/[root-of-the-server]__07aae1e._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_templates_route_actions_1kz0oyw.js")
R.m(39679)
module.exports=R.m(39679).exports

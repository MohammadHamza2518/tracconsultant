var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/filings/route.js")
R.c("server/chunks/[root-of-the-server]__0kjqg60._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_filings_route_actions_0doth_6.js")
R.m(58464)
module.exports=R.m(58464).exports

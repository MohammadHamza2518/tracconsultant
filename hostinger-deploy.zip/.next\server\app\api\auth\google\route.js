var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/route.js")
R.c("server/chunks/[root-of-the-server]__109y5vl._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_route_actions_0rae5gv.js")
R.m(88214)
module.exports=R.m(88214).exports
